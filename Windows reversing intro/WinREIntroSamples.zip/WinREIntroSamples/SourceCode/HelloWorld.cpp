#include <iostream>

int main() {
	printf("%s\n","Hello with printf()!");
	std::cout << "Hello with stdout!" << std::endl;
	return 0;
}